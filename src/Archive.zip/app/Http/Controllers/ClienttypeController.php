<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ClienttypeController extends Controller
{
    //
}
