<?php

namespace App\Http\Controllers\RequestService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Inertia\Inertia;


class RequestServiceController extends Controller
{
    
}
