<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RequestServicesStatus extends Model
{
    protected $table = 'request_services_status';
    
    use HasFactory;
}
